package app.wonton.ui.icons

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.unit.dp

@Suppress("UnusedReceiverParameter")
val WontonIcon.Warning: ImageVector by lazy(LazyThreadSafetyMode.NONE) {
    ImageVector.Builder(
        name = "Warning",
        defaultWidth = 256.dp,
        defaultHeight = 256.dp,
        viewportWidth = 256f,
        viewportHeight = 256f
    ).apply {
        addPath(
            fill = SolidColor(Color.Black),
            pathData = addPathNodes("M 236.8 188.09 L 149.35 36.22 h 0.0 a 24.76 24.76 0.0 0 0 -42.7 0.0 L 19.2 188.09 a 23.51 23.51 0.0 0 0 0.0 23.72 A 24.35 24.35 0.0 0 0 40.55 224.0 h 174.9 a 24.35 24.35 0.0 0 0 21.33 -12.19 A 23.51 23.51 0.0 0 0 236.8 188.09 Z M 222.93 203.8 a 8.5 8.5 0.0 0 1 -7.48 4.2 L 40.55 208.0 a 8.5 8.5 0.0 0 1 -7.48 -4.2 a 7.59 7.59 0.0 0 1 0.0 -7.72 L 120.52 44.21 a 8.75 8.75 0.0 0 1 15.0 0.0 l 87.45 151.87 A 7.59 7.59 0.0 0 1 222.93 203.8 Z M 120.0 144.0 L 120.0 104.0 a 8.0 8.0 0.0 0 1 16.0 0.0 v 40.0 a 8.0 8.0 0.0 0 1 -16.0 0.0 Z M 140.0 180.0 a 12.0 12.0 0.0 1 1 -12.0 -12.0 A 12.0 12.0 0.0 0 1 140.0 180.0 Z")
        )
    }.build()
}
